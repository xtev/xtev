
LITTLE ROOM PROUDLY PRESENTS...

HAPPY THANKS GIVING ITS A TURKEY BOSS OH WOW!!!!

Terms of Use.

By using or installing this product you are agreeing to the terms of use as follows:

You may promote servers/plugins/maps using Littleroom mobs or add-ons either with the 
provided promotional art or otherwise under the condition that the user-end provides 
credit to the creator in written form (ie. Youtube video descriptions).

You may alter the configuration of Littleroom mobs or add-ons to fit your style or server needs, but under no circumstance make those changes available for purchase.

You may alter the textures of Littleroom mobs or add-ons to fit your style or server needs, but under no circumstance make those changes available for purchase.

You may alter the model files of Littleroom mobs or add-ons to fit your style or server needs, but under no circumstance make those changes available for purchase.

You may not make any Littleroom mobs or add-ons available for download on third-party websites.

The bottom line is, you may do what you wish with these products but credit must be reasonably displayed anywhere the product is seen and must not be monetized in any form (ie. adfly links).

Littleroom creations are protected under International Copyright and Intellectual Property Law and misuse will be handled as a breach of terms.




Installation Instructions:

YOUTUBE tutorial version: https://youtu.be/HUyNJcCd4FU

STEP 1:
You can either use the provided resourcepack zip file provided for your server or you can combine it with your current
resourcepack although it may prompt you that its going to overwrite the 'leather_horse_armor.json' that is standard 
procedure for the ModelEngine.

STEP 2:
Please make sure you have MythicMobs and ModelEngine installed, the free versions should work just fine.
Copy both 'MythicMobs' and 'ModelEngine' into your plugins folder of your server.

It may ask to overwrite the 'VanillaMobs.yml' I included this config so that the Shark may attack dolphins as I planned 
but you can opt out if you want if you think it may cause conflict.

STEP 3:
Restart the server and check it out, you can spawn the mobs with the MythicMobs commands '/mm mobs spawn' and then the mob
name after that.

HOTTIP!
if you are adding this pack to any modelengine mobpack (not just mine) you will have to run the command "/meg reload models"
and then go to your modelengine plugin folder -> resourcepack folder and copy that asset folder into your current resourcepack.

DISCLAIMER:
there are some drawbacks to using ModelEngine that may get patched out in the future (whoknows?) but sometimes the model parts
will separate, that's just the nature of how this plugins works at the moment.

You can remedy this by going into the ModelEngine config.yml and changing the parameter 'Force-Update-Tick:' and set it to
1 for a faster refreshing, although this has the potential lag a lower spec server, especially if there are tons of
custom mobs running around.


Feel free to come to me for any questions or help at, https://discord.gg/ERfXxsd